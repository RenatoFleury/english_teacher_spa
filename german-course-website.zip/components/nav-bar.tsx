import Link from "next/link"
import { Button } from "@/components/ui/button"

export function NavBar() {
  return (
    <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto w-full">
      <Link href="/" className="text-rose-500 text-2xl font-bold">
        Sprechende
      </Link>

      <div className="hidden md:flex items-center gap-8">
        <Link href="/nosso-metodo" className="text-neutral-700 hover:text-rose-500 transition-colors">
          Nosso Método
        </Link>
        <Link href="/cursos" className="text-neutral-700 hover:text-rose-500 transition-colors">
          Cursos
        </Link>
        <Link href="/depoimentos" className="text-neutral-700 hover:text-rose-500 transition-colors">
          Depoimentos
        </Link>
        <Link href="/sobre" className="text-neutral-700 hover:text-rose-500 transition-colors">
          Sobre
        </Link>
        <Link href="/contato" className="text-neutral-700 hover:text-rose-500 transition-colors">
          Contato
        </Link>
        <Button className="bg-rose-500 hover:bg-rose-600 text-white rounded-full px-6">Aula experimental</Button>
      </div>
    </nav>
  )
}

