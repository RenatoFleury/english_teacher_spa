import Image from "next/image"

export function HeroSection() {
  return (
    <div className="min-h-[calc(100vh-80px)]">
      <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold leading-tight">
            <span className="bg-gradient-to-r from-rose-500 to-orange-500 bg-clip-text text-transparent">
              Cursos de
              <br />
              Alemão Online
            </span>
          </h1>
          <p className="text-neutral-700 text-lg max-w-xl">
            Na Sprechende, sua aprendizagem é personalizada. Nossa missão é ensinar alemão em um espaço seguro e
            acolhedor, no qual você se sinta à vontade para explorar, se expressar e até errar (sim, os erros fazem
            parte do processo).
          </p>
        </div>
        <div className="relative h-[400px] md:h-[500px]">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-y1vESnXcf7UtzuzR7hscARmk8VrmPG.png"
            alt="Student learning German online"
            fill
            className="object-contain"
            priority
          />
        </div>
      </div>
    </div>
  )
}

